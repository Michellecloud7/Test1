

package com.mycompany.electronics_stores;

/**
 *
 * @author Student
 */
public class Electronics_stores {

    public static void main(String[] args) {
        
    }
}
