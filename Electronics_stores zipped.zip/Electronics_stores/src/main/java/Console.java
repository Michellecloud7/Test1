

/**
 *
 * @author Student
 */
public abstract class Console implements IConsole {
    private String devicename;
    private String store_name;
    private int total_sales;
    
    public Console(String devicename, store_name, int total_sales){
        this.devicename = devicename;
        this.store_name = store_name;
        this.total_sales = total_sales;
    }
    @Override
    public String getdevicename() {
        return devicename;
    }
    @Override
    public String getstore_name() {
        return store_name;
    }
    @Override
    public int gettotal_sales(){
        return total_sales;
    }
    
}
