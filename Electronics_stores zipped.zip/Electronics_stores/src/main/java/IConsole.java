/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author Student
 */
public interface IConsole {
    String getdevicename();
    String getstore_name();
    int gettotal_sales();
}
